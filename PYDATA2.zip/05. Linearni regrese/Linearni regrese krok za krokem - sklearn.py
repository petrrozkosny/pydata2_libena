import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

# Vytvoření DataFrame
data = pd.DataFrame({
    # Nezávislá proměnná (X)
    'Hodiny_studia': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    # Závislá proměnná (Y)
    'Body_na_zkousce': [2, 4, 5, 4, 5, 6, 7, 8, 8, 9]
})

# Rozdělení dat na trénovací a testovací sady
X = data[['Hodiny_studia']]
y = data['Body_na_zkousce']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Vytvoření a trénování modelu lineární regrese
model = LinearRegression()
model.fit(X_train, y_train)

# Ověření modelu na testovací sadě
y_pred = model.predict(X_test)

# Výpočet koeficientů
print("Koeficienty modelu:")
print("Intercept:", model.intercept_)
print("Koeficient nezávislé proměnné:", model.coef_[0])

# Uživatel zadává vlastní hodnotu nezávislé proměnné
vstup = float(input("Zadejte hodnotu nezávislé proměnné: "))

# Předpověď hodnoty závislé proměnné
predikce = model.predict([[vstup]])
print("Předpovězená hodnota závislé proměnné:", predikce[0])
